# TAMU GUI — SOHBET-16 Final Onaylı Paket

Bu paket yalnız SOHBET-16 sırasında açıkça onaylanan nihai PNG’leri içerir. Revize edilen veya reddedilen ara sürümler dahil edilmemiştir.

## Tam ekran ana referanslar

- `126112.png` — Onaylı normal gameplay HUD ana referansı. (1536×864, RGB)
- `126120.png` — Onaylı Inventory açık ekran ana referansı. (1536×865, RGB)
- `126122.png` — Onaylı Chest açık ekran ana referansı. (1536×864, RGB)
- `126124.png` — Onaylı Pause / Audio açık ekran ana referansı; Audio aktif state. (1536×864, RGB)
- `126126.png` — Onaylı Map açık ekran ana referansı; Mini-map aktif state. (1536×864, RGB)

## Onaylı component PNG’leri

- `126108.png` — Normal hotbar slotu + seçili hotbar slotu + çanta ikonu. (2172×724, RGBA)
- `126113.png` — Pause ikonu + Mini-map ikonu. (1941×810, RGBA)
- `126114.png` — Health + Hunger + Thirst + Day/Night ikonları. (2172×724, RGBA)
- `126116.png` — Survival HUD paneli + normal kare düğme + altın iç-haleli aktif kare düğme. (2172×724, RGBA)
- `126117.png` — Büyük menü penceresi + X kapatma ikonu + inventory/chest slotu. (1941×810, RGBA)
- `126118.png` — Audio slider track + slider handle + yatay divider. (2172×724, RGBA)
- `126127.png` — Ana title plaque + normal geniş yatay menü düğmesi + iç içerik/map frame. (2172×724, RGBA)
- `126128.png` — Aktif/basılı geniş yatay menü düğmesi. (2172×724, RGBA)
- `126129.png` — Küçük bölüm başlık plakası (örn. Chest içindeki Inventory başlığı). (2172×724, RGBA)
- `126130.png` — North indicator + player position marker. (1941×810, RGBA)
- `126131.png` — Dolu Health/Hunger/Thirst bar segmentleri. (2172×724, RGBA)
- `126133.png` — Nötr/inaktif survival bar segmenti. (1312×1199, RGBA)
- `126134.png` — Hotbar ile Bag arasındaki dikey divider. (887×1774, RGBA)
- `126138.png` — Inventory/Chest item quantity badge. (1263×1246, RGBA)

## SOHBET-17 entegrasyon notları

- Tam ekran referanslar görsel hedef/ölçü referansıdır; oyun içinde tek parça UI resmi olarak kullanılmamalıdır.
- Metinler, sayaçlar, item quantity değerleri, slider değerleri ve dinamik map içeriği Godot tarafında ayrı tutulmalıdır.
- Inventory/Chest item ikonları oyun verisindeki gerçek item görsellerinden gelmelidir.
- Map terrain görüntüsü sabit PNG component değildir; mevcut mini-map/world verisi tarafından çizilmelidir.
- Modal arka plan karartması Godot tarafında uygulanmalıdır.
- `126120.png` onaylı referans dosyası 1536×865’tir; entegrasyonda hedef 16:9 viewport’a yerleşim referansı olarak kullanılmalı, görseli zorla 1:1 piksel ekran çıktısı olarak ele almamalıdır.
- Font, metin outline/shadow, anchor/pivot, nine-slice sınırları ve exact Godot ölçüleri SOHBET-17’de referans ekranlarla eşleştirilmelidir.

## Pakete dahil edilmeyen ara/reddedilen sürümler

`126111`, `126115`, `126119`, `126121`, `126123`, `126125`, `126132`, `126135`, `126136`, `126137` ve diğer ara çıktılar nihai paket dışında bırakılmıştır.

Repo değişikliği yapılmadı.